<?php echo "teste"; ?>

<?php print_r($displayData['data']); ?>